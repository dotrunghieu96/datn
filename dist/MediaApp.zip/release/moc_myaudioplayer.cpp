/****************************************************************************
** Meta object code from reading C++ file 'myaudioplayer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Project_MediaApp/Media/myaudioplayer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'myaudioplayer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MyAudioPlayer_t {
    QByteArrayData data[28];
    char stringdata0[361];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MyAudioPlayer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MyAudioPlayer_t qt_meta_stringdata_MyAudioPlayer = {
    {
QT_MOC_LITERAL(0, 0, 13), // "MyAudioPlayer"
QT_MOC_LITERAL(1, 14, 22), // "nowPlayingIndexChanged"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 15), // "nowPlayingIndex"
QT_MOC_LITERAL(4, 54, 19), // "playbackModeChanged"
QT_MOC_LITERAL(5, 74, 11), // "currentMode"
QT_MOC_LITERAL(6, 86, 15), // "durationChanged"
QT_MOC_LITERAL(7, 102, 8), // "duration"
QT_MOC_LITERAL(8, 111, 15), // "positionChanged"
QT_MOC_LITERAL(9, 127, 8), // "position"
QT_MOC_LITERAL(10, 136, 21), // "mediaAvailableChanged"
QT_MOC_LITERAL(11, 158, 14), // "mediaAvailable"
QT_MOC_LITERAL(12, 173, 16), // "isPlayingChanged"
QT_MOC_LITERAL(13, 190, 9), // "isPlaying"
QT_MOC_LITERAL(14, 200, 6), // "nexted"
QT_MOC_LITERAL(15, 207, 6), // "isNext"
QT_MOC_LITERAL(16, 214, 8), // "setMedia"
QT_MOC_LITERAL(17, 223, 5), // "index"
QT_MOC_LITERAL(18, 229, 20), // "setPositionByPercent"
QT_MOC_LITERAL(19, 250, 7), // "percent"
QT_MOC_LITERAL(20, 258, 18), // "switchPlaybackMode"
QT_MOC_LITERAL(21, 277, 10), // "togglePlay"
QT_MOC_LITERAL(22, 288, 4), // "next"
QT_MOC_LITERAL(23, 293, 8), // "previous"
QT_MOC_LITERAL(24, 302, 13), // "getTimeString"
QT_MOC_LITERAL(25, 316, 11), // "miliseconds"
QT_MOC_LITERAL(26, 328, 19), // "mediaChangedHandler"
QT_MOC_LITERAL(27, 348, 12) // "playbackMode"

    },
    "MyAudioPlayer\0nowPlayingIndexChanged\0"
    "\0nowPlayingIndex\0playbackModeChanged\0"
    "currentMode\0durationChanged\0duration\0"
    "positionChanged\0position\0mediaAvailableChanged\0"
    "mediaAvailable\0isPlayingChanged\0"
    "isPlaying\0nexted\0isNext\0setMedia\0index\0"
    "setPositionByPercent\0percent\0"
    "switchPlaybackMode\0togglePlay\0next\0"
    "previous\0getTimeString\0miliseconds\0"
    "mediaChangedHandler\0playbackMode"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MyAudioPlayer[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       6,  124, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   89,    2, 0x06 /* Public */,
       4,    1,   92,    2, 0x06 /* Public */,
       6,    1,   95,    2, 0x06 /* Public */,
       8,    1,   98,    2, 0x06 /* Public */,
      10,    1,  101,    2, 0x06 /* Public */,
      12,    1,  104,    2, 0x06 /* Public */,
      14,    1,  107,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      16,    1,  110,    2, 0x0a /* Public */,
      18,    1,  113,    2, 0x0a /* Public */,
      20,    0,  116,    2, 0x0a /* Public */,
      21,    0,  117,    2, 0x0a /* Public */,
      22,    0,  118,    2, 0x0a /* Public */,
      23,    0,  119,    2, 0x0a /* Public */,
      24,    1,  120,    2, 0x0a /* Public */,
      26,    0,  123,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::LongLong,    7,
    QMetaType::Void, QMetaType::LongLong,    9,
    QMetaType::Void, QMetaType::Bool,   11,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, QMetaType::Bool,   15,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::QString, QMetaType::LongLong,   25,
    QMetaType::Void,

 // properties: name, type, flags
       7, QMetaType::LongLong, 0x00495001,
       9, QMetaType::LongLong, 0x00495001,
      11, QMetaType::Bool, 0x00495001,
      13, QMetaType::Bool, 0x00495001,
       3, QMetaType::Int, 0x00495001,
      27, QMetaType::Int, 0x00495001,

 // properties: notify_signal_id
       2,
       3,
       4,
       5,
       0,
       1,

       0        // eod
};

void MyAudioPlayer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MyAudioPlayer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->nowPlayingIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->playbackModeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->durationChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 3: _t->positionChanged((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 4: _t->mediaAvailableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->isPlayingChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->nexted((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->setMedia((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 8: _t->setPositionByPercent((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 9: _t->switchPlaybackMode(); break;
        case 10: _t->togglePlay(); break;
        case 11: _t->next(); break;
        case 12: _t->previous(); break;
        case 13: { QString _r = _t->getTimeString((*reinterpret_cast< qint64(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 14: _t->mediaChangedHandler(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MyAudioPlayer::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MyAudioPlayer::nowPlayingIndexChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MyAudioPlayer::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MyAudioPlayer::playbackModeChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MyAudioPlayer::*)(qint64 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MyAudioPlayer::durationChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MyAudioPlayer::*)(qint64 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MyAudioPlayer::positionChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (MyAudioPlayer::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MyAudioPlayer::mediaAvailableChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (MyAudioPlayer::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MyAudioPlayer::isPlayingChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (MyAudioPlayer::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MyAudioPlayer::nexted)) {
                *result = 6;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<MyAudioPlayer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< qint64*>(_v) = _t->duration(); break;
        case 1: *reinterpret_cast< qint64*>(_v) = _t->position(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->mediaAvailable(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->isPlaying(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->nowPlayingIndex(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->playbackMode(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject MyAudioPlayer::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_MyAudioPlayer.data,
    qt_meta_data_MyAudioPlayer,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MyAudioPlayer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MyAudioPlayer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MyAudioPlayer.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int MyAudioPlayer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void MyAudioPlayer::nowPlayingIndexChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MyAudioPlayer::playbackModeChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MyAudioPlayer::durationChanged(qint64 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MyAudioPlayer::positionChanged(qint64 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MyAudioPlayer::mediaAvailableChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void MyAudioPlayer::isPlayingChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void MyAudioPlayer::nexted(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
