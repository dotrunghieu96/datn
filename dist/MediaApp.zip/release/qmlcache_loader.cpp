#include <QtQml/qqmlprivate.h>
#include <QtCore/qdir.h>
#include <QtCore/qurl.h>

static const unsigned char qt_resource_tree[] = {
0,
0,0,0,0,2,0,0,0,2,0,0,0,1,0,0,0,
30,0,2,0,0,0,6,0,0,0,3,0,0,0,8,0,
0,0,0,0,1,0,0,0,0,0,0,0,42,0,0,0,
0,0,1,0,0,0,0,0,0,0,186,0,0,0,0,0,
1,0,0,0,0,0,0,0,216,0,0,0,0,0,1,0,
0,0,0,0,0,0,114,0,0,0,0,0,1,0,0,0,
0,0,0,0,150,0,0,0,0,0,1,0,0,0,0,0,
0,0,72,0,0,0,0,0,1,0,0,0,0};
static const unsigned char qt_resource_names[] = {
0,
1,0,0,0,47,0,47,0,8,8,1,90,92,0,109,0,
97,0,105,0,110,0,46,0,113,0,109,0,108,0,3,0,
0,88,60,0,81,0,109,0,108,0,12,1,100,56,92,0,
65,0,117,0,100,0,105,0,111,0,65,0,112,0,112,0,
46,0,113,0,109,0,108,0,18,15,16,69,220,0,68,0,
97,0,116,0,101,0,84,0,105,0,109,0,101,0,87,0,
105,0,100,0,103,0,101,0,116,0,46,0,113,0,109,0,
108,0,15,10,76,194,220,0,86,0,105,0,100,0,101,0,
111,0,80,0,108,0,97,0,121,0,101,0,114,0,46,0,
113,0,109,0,108,0,15,11,207,205,156,0,65,0,117,0,
100,0,105,0,111,0,87,0,105,0,100,0,103,0,101,0,
116,0,46,0,113,0,109,0,108,0,12,1,250,113,92,0,
77,0,121,0,66,0,117,0,116,0,116,0,111,0,110,0,
46,0,113,0,109,0,108,0,12,3,236,16,92,0,86,0,
105,0,100,0,101,0,111,0,65,0,112,0,112,0,46,0,
113,0,109,0,108};
static const unsigned char qt_resource_empty_payout[] = { 0, 0, 0, 0, 0 };
QT_BEGIN_NAMESPACE
extern Q_CORE_EXPORT bool qRegisterResourceData(int, const unsigned char *, const unsigned char *, const unsigned char *);
QT_END_NAMESPACE
namespace QmlCacheGeneratedCode {
namespace _0x5f_Qml_VideoApp_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _0x5f_Qml_MyButton_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _0x5f_Qml_AudioWidget_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _0x5f__main_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _0x5f_Qml_VideoPlayer_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _0x5f_Qml_DateTimeWidget_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _0x5f_Qml_AudioApp_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}

}
namespace {
struct Registry {
    Registry();
    ~Registry();
    QHash<QString, const QQmlPrivate::CachedQmlUnit*> resourcePathToCachedUnit;
    static const QQmlPrivate::CachedQmlUnit *lookupCachedUnit(const QUrl &url);
};

Q_GLOBAL_STATIC(Registry, unitRegistry)


Registry::Registry() {
        resourcePathToCachedUnit.insert(QStringLiteral("/Qml/VideoApp.qml"), &QmlCacheGeneratedCode::_0x5f_Qml_VideoApp_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/Qml/MyButton.qml"), &QmlCacheGeneratedCode::_0x5f_Qml_MyButton_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/Qml/AudioWidget.qml"), &QmlCacheGeneratedCode::_0x5f_Qml_AudioWidget_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/main.qml"), &QmlCacheGeneratedCode::_0x5f__main_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/Qml/VideoPlayer.qml"), &QmlCacheGeneratedCode::_0x5f_Qml_VideoPlayer_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/Qml/DateTimeWidget.qml"), &QmlCacheGeneratedCode::_0x5f_Qml_DateTimeWidget_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/Qml/AudioApp.qml"), &QmlCacheGeneratedCode::_0x5f_Qml_AudioApp_qml::unit);
    QQmlPrivate::RegisterQmlUnitCacheHook registration;
    registration.version = 0;
    registration.lookupCachedQmlUnit = &lookupCachedUnit;
    QQmlPrivate::qmlregister(QQmlPrivate::QmlUnitCacheHookRegistration, &registration);
QT_PREPEND_NAMESPACE(qRegisterResourceData)(/*version*/0x01, qt_resource_tree, qt_resource_names, qt_resource_empty_payout);
}

Registry::~Registry() {
    QQmlPrivate::qmlunregister(QQmlPrivate::QmlUnitCacheHookRegistration, quintptr(&lookupCachedUnit));
}

const QQmlPrivate::CachedQmlUnit *Registry::lookupCachedUnit(const QUrl &url) {
    if (url.scheme() != QLatin1String("qrc"))
        return nullptr;
    QString resourcePath = QDir::cleanPath(url.path());
    if (resourcePath.isEmpty())
        return nullptr;
    if (!resourcePath.startsWith(QLatin1Char('/')))
        resourcePath.prepend(QLatin1Char('/'));
    return unitRegistry()->resourcePathToCachedUnit.value(resourcePath, nullptr);
}
}
int QT_MANGLE_NAMESPACE(qInitResources_qml)() {
    ::unitRegistry();
    Q_INIT_RESOURCE(qml_qmlcache);
    return 1;
}
Q_CONSTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qInitResources_qml))
int QT_MANGLE_NAMESPACE(qCleanupResources_qml)() {
    Q_CLEANUP_RESOURCE(qml_qmlcache);
    return 1;
}
